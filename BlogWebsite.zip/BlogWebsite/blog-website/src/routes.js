// routes.js

const express = require('express');
const router = express.Router();
const Post = require('./models/post');

// Index route
router.get('/', async (req, res) => {
  console.log(__dirname);
  const posts = await Post.find({});
  res.render('index', { posts });
});

// New post route
router.get('/posts/new', (req, res) => {
  res.render('new');
});

// Create post route
router.post('/posts', async (req, res) => {
  await Post.create(req.body.post);
  res.redirect('/');
});

// Show post route
router.get('/posts/:id', async (req, res) => {
  const post = await Post.findById(req.params.id);
  res.render('show', { post });
});

module.exports = router;